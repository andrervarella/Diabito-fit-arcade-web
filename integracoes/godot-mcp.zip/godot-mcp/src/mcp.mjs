import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import * as z from 'zod/v4';
const ALL_SCOPES=['godot:read','godot:write','godot:run'];
const result=value=>({content:[{type:'text',text:JSON.stringify(value,null,2)}],structuredContent:value});

export function createMcpServer(bridge,{scopes=ALL_SCOPES}={}){
  const server=new McpServer({name:'diabito-godot-mcp',version:'0.1.0'});
  function tool(name,description,inputSchema,scope,action,{readOnly=false,destructive=false,idempotent=false}={}){
    server.registerTool(name,{description,inputSchema,annotations:{readOnlyHint:readOnly,destructiveHint:destructive,idempotentHint:idempotent,openWorldHint:false}},async input=>{
      try{
        if(!scopes.includes(scope))throw Error('Permissão OAuth necessária: '+scope+'. Reconecte e autorize essa permissão.');
        return result(await action(input));
      }catch(error){return {isError:true,content:[{type:'text',text:error.message}]};}
    });
  }
  tool('get_project_info','Get the configured Godot project name and paths. Does not access another project.',{},'godot:read',()=>bridge.info(),{readOnly:true,idempotent:true});
  tool('list_project_files','List up to 500 project files, excluding .godot, .git, node_modules and symbolic links.',{},'godot:read',()=>bridge.listFiles(),{readOnly:true,idempotent:true});
  tool('read_project_file','Read a text resource inside the project and obtain its SHA256 for a later edit.',{path:z.string().min(1).describe('Project-relative or res:// path')},'godot:read',({path})=>bridge.readFile(path),{readOnly:true,idempotent:true});
  tool('write_project_file','Create or update a project text file. To update an existing file, first read it and supply its current SHA256. No arbitrary outside paths, binary writes, or deletion.',{path:z.string().min(1),content:z.string().max(1048576),expectedSha256:z.string().regex(/^[a-f0-9]{64}$/).optional()},'godot:write',({path,content,expectedSha256})=>bridge.writeFile(path,content,expectedSha256),{destructive:true});
  tool('check_project','Run Godot headless import/validation. Optional script checks one .gd file. This executes the configured Godot project/editor, including its own import/tool code.',{script:z.string().optional()},'godot:run',({script})=>bridge.checkProject(script));
  tool('run_project','Start the configured project in Godot headless and collect logs. Optionally choose one .tscn scene. Only one managed Godot process runs at a time.',{scene:z.string().optional()},'godot:run',({scene})=>bridge.runProject(scene));
  tool('get_project_output','Read recent logs and process status from the managed Godot run/editor.',{},'godot:read',()=>bridge.output(),{readOnly:true,idempotent:true});
  tool('stop_project','Stop only the Godot process launched by this bridge, leaving other editor instances alone.',{},'godot:run',()=>bridge.stopProject(),{idempotent:true});
  tool('launch_editor','Open this project in the local Godot desktop editor. Requires an available desktop display; headless servers should use run_project instead.',{},'godot:run',()=>bridge.launchEditor());
  return server;
}
