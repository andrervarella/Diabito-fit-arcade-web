#!/usr/bin/env node
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import express from 'express';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
import {StreamableHTTPServerTransport} from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import {mcpAuthRouter,getOAuthProtectedResourceMetadataUrl} from '@modelcontextprotocol/sdk/server/auth/router.js';
import {requireBearerAuth} from '@modelcontextprotocol/sdk/server/auth/middleware/bearerAuth.js';
import {createMcpExpressApp} from '@modelcontextprotocol/sdk/server/express.js';
import {GodotBridge} from './bridge.mjs';
import {createMcpServer} from './mcp.mjs';
import {createOwnerAuth} from './auth.mjs';

export async function createHttpServer({bridge,publicUrl,password,host='127.0.0.1',port=3978}={}){
  const origin=new URL(publicUrl);
  // Validate credentials and external origin before opening a listening socket.
  const {provider,approveHandler}=createOwnerAuth({publicUrl:origin,password});
  if(!Number.isInteger(port)||port<0||port>65535)throw Error('MCP_PORT inválida.');
  const resource=new URL('/mcp',origin);
  const allowedHosts=[...new Set([origin.hostname,'127.0.0.1','localhost','[::1]'])];
  const app=createMcpExpressApp({host,allowedHosts});
  app.disable('x-powered-by');
  app.get('/health',(_request,response)=>response.json({ok:true,service:'Godot MCP',authentication:'OAuth2.1',version:'0.1.0'}));
  app.get('/',(_request,response)=>response.type('text').send('Godot MCP ativo. Conecte o aplicativo MCP ao endpoint /mcp usando OAuth.'));
  app.post('/approve',express.urlencoded({extended:false,limit:'8kb'}),approveHandler);
  app.use(mcpAuthRouter({provider,issuerUrl:origin,baseUrl:origin,resourceServerUrl:resource,scopesSupported:['godot:read','godot:write','godot:run'],resourceName:'Projeto Godot local'}));
  const authenticated=requireBearerAuth({verifier:provider,resourceMetadataUrl:getOAuthProtectedResourceMetadataUrl(resource),expectedResource:resource});
  app.post('/mcp',authenticated,async(request,response)=>{
    const server=createMcpServer(bridge,{scopes:request.auth.scopes});
    const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});
    response.on('close',()=>{void transport.close();void server.close();});
    try{await server.connect(transport);await transport.handleRequest(request,response,request.body);}
    catch(error){
      console.error('Falha de transporte MCP:',error.message);
      if(!response.headersSent)response.status(500).json({jsonrpc:'2.0',id:null,error:{code:-32603,message:'Erro interno no transporte MCP.'}});
    }
  });
  app.all('/mcp',authenticated,(_request,response)=>response.status(405).set('Allow','POST').json({error:'Use POST com Streamable HTTP. Este servidor não mantém uma sessão SSE.'}));
  // Avoid returning stack traces or filesystem paths in generic HTTP errors.
  app.use((error,_request,response,_next)=>{if(!response.headersSent)response.status(error.status||500).json({error:'Requisição inválida.'});});
  const listener=await new Promise((resolve,reject)=>{const listener=app.listen(port,host,()=>resolve(listener));listener.once('error',reject);});
  const close=()=>new Promise((resolve,reject)=>{listener.close(error=>error?reject(error):resolve());listener.closeIdleConnections?.();});
  return {listener,close,publicUrl:origin.href,resourceUrl:resource.href};
}

async function main(){
  const bridge=await GodotBridge.create({projectPath:process.env.GODOT_PROJECT_PATH,godotBin:process.env.GODOT_BIN||'godot'});
  let close;
  if(process.argv.includes('--stdio')){
    const server=createMcpServer(bridge);const transport=new StdioServerTransport();await server.connect(transport);
    close=()=>server.close();
    process.stdin.once('end',()=>{void bridge.close().finally(()=>process.exit(0));});
    console.error('Godot MCP STDIO pronto; projeto configurado.');
  }else{
    const port=Number(process.env.MCP_PORT||3978);
    const publicUrl=process.env.MCP_PUBLIC_URL||`http://127.0.0.1:${port}`;
    const http=await createHttpServer({bridge,publicUrl,password:process.env.MCP_OWNER_PASSWORD,host:process.env.MCP_HOST||'127.0.0.1',port});
    close=http.close;
    console.error(`Godot MCP HTTP pronto em ${http.resourceUrl}; requer OAuth e senha do dono. Nenhum cliente foi conectado automaticamente.`);
  }
  let closing=false;
  const shutdown=async()=>{if(closing)return;closing=true;await bridge.close();await close?.();process.exit(0);};
  process.once('SIGINT',()=>{void shutdown();});process.once('SIGTERM',()=>{void shutdown();});
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 main().catch(error=>{console.error(error.message);process.exitCode=1;});
}
