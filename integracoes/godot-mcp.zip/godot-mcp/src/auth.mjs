import {createHash, randomBytes, randomUUID, timingSafeEqual} from 'node:crypto';
import {
  InvalidClientMetadataError, InvalidGrantError, InvalidRequestError,
  InvalidScopeError, InvalidTargetError, InvalidTokenError, TemporarilyUnavailableError,
} from '@modelcontextprotocol/sdk/server/auth/errors.js';

const SCOPES = Object.freeze(['godot:read', 'godot:write', 'godot:run']);
const randomToken = () => randomBytes(32).toString('base64url');
const digest = value => createHash('sha256').update(String(value)).digest();
const html = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));

/** Single-owner prototype. SDK routes perform OAuth parameter and PKCE validation. */
export function createOwnerAuth({publicUrl, password, now = Date.now}) {
  if (typeof password !== 'string' || password.trim().length < 16) {
    throw new Error('MCP_OWNER_PASSWORD deve conter pelo menos 16 caracteres.');
  }
  const origin = new URL(publicUrl);
  if (origin.pathname !== '/' || origin.search || origin.hash || origin.username || origin.password) {
    throw new Error('MCP_PUBLIC_URL deve ser a origem pública, sem caminho, credenciais ou parâmetros.');
  }
  if (origin.protocol !== 'https:' && !(origin.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(origin.hostname))) {
    throw new Error('MCP_PUBLIC_URL precisa usar HTTPS, exceto localhost.');
  }
  const resourceUrl = new URL('/mcp', origin);
  const passwordHash = digest(password);
  const clients = new Map(), pending = new Map(), codes = new Map(), tokens = new Map();
  let loginWindowStart = now(), loginAttempts = 0;

  const prune = () => {
    const timestamp = now();
    for (const store of [pending, codes, tokens]) {
      for (const [key, value] of store) if (value.expiresAt <= timestamp) store.delete(key);
    }
  };
  const bounded = (store, limit) => {
    prune();
    if (store.size >= limit) throw new TemporarilyUnavailableError('Limite temporário atingido; tente novamente mais tarde.');
  };
  const checkResource = (resource, ErrorType = InvalidTargetError) => {
    if (resource && new URL(resource).href !== resourceUrl.href) {
      throw new ErrorType('O recurso solicitado não corresponde a este servidor Godot.');
    }
    return new URL(resourceUrl);
  };
  const scopesFor = scopes => {
    const requested = scopes?.length ? [...new Set(scopes)] : [...SCOPES];
    if (requested.some(scope => !SCOPES.includes(scope))) throw new InvalidScopeError('Permissão não suportada.');
    return requested;
  };
  const validCode = (client, code) => {
    prune();
    const entry = codes.get(code);
    if (!entry || entry.clientId !== client.client_id) throw new InvalidGrantError('Código inválido ou expirado para este cliente.');
    return entry;
  };
  const revokeGrant = grantId => {
    for (const [key, entry] of tokens) if (entry.grantId === grantId) tokens.delete(key);
  };
  const issueTokens = ({clientId, scopes, grantId = randomUUID()}) => {
    bounded(tokens, 2046);
    const access = randomToken(), refresh = randomToken(), timestamp = now();
    const common = {clientId, scopes:[...scopes], grantId};
    tokens.set(access, {...common, kind:'access', expiresAt:timestamp + 3600000});
    tokens.set(refresh, {...common, kind:'refresh', expiresAt:timestamp + 7 * 86400000});
    return {access_token:access, token_type:'Bearer', expires_in:3600, refresh_token:refresh, scope:scopes.join(' ')};
  };
  const redirectWith = (response, uri, values) => {
    const target = new URL(uri);
    for (const [key, value] of Object.entries(values)) if (value !== undefined) target.searchParams.set(key, value);
    response.redirect(302, target.href);
  };
  const securePage = response => {
    response.setHeader('Cache-Control', 'no-store');
    response.setHeader('Pragma', 'no-cache');
    response.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
  };

  const provider = {
    clientsStore: {
      getClient: async clientId => clients.get(clientId),
      registerClient: async metadata => {
        if (clients.size >= 256) throw new TemporarilyUnavailableError('Limite de clientes atingido; reinicie a ponte para limpar cadastros antigos.');
        if (!Array.isArray(metadata.redirect_uris) || !metadata.redirect_uris.length || metadata.redirect_uris.length > 10) {
          throw new InvalidClientMetadataError('Informe até 10 endereços de retorno.');
        }
        for (const value of metadata.redirect_uris) {
          const uri = new URL(value);
          const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(uri.hostname);
          if (uri.hash || uri.username || uri.password || (uri.protocol !== 'https:' && !(uri.protocol === 'http:' && loopback))) {
            throw new InvalidClientMetadataError('O retorno precisa usar HTTPS ou HTTP em localhost.');
          }
        }
        const client = {...metadata, client_id:metadata.client_id || randomUUID(), client_id_issued_at:metadata.client_id_issued_at || Math.floor(now() / 1000)};
        clients.set(client.client_id, client);
        return client;
      },
    },
    async authorize(client, params, response) {
      if (!client.redirect_uris.includes(params.redirectUri)) throw new InvalidRequestError('Endereço de retorno não cadastrado.');
      checkResource(params.resource);
      const scopes = scopesFor(params.scopes);
      if (typeof params.codeChallenge !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(params.codeChallenge)) throw new InvalidRequestError('PKCE S256 é obrigatório.');
      bounded(pending, 256);
      const ticket = randomToken();
      pending.set(ticket, {clientId:client.client_id, redirectUri:params.redirectUri, state:params.state, codeChallenge:params.codeChallenge, scopes, expiresAt:now() + 600000});
      securePage(response);
      response.type('html').send(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Autorizar Godot MCP</title><style>body{font:17px/1.5 system-ui;max-width:560px;margin:40px auto;padding:20px;background:#121920;color:#f2f6fa}input,button{font:inherit;padding:12px;box-sizing:border-box}input{width:100%}button{margin-top:16px}code{word-break:break-all}label{display:block;margin-top:20px}</style></head><body><h1>Conectar ao seu Godot</h1><p>O aplicativo <strong>${html(client.client_name || 'Cliente MCP')}</strong> pediu acesso ao projeto configurado nesta ponte.</p><p>Permissões: <code>${html(scopes.join(', '))}</code>.</p><p>Autorize somente o pedido que você iniciou. A senha é a <code>MCP_OWNER_PASSWORD</code> configurada no seu computador.</p><form method="post" action="/approve"><input type="hidden" name="ticket" value="${ticket}"><label>Senha da ponte<input type="password" name="password" autocomplete="current-password" required minlength="16" maxlength="1024"></label><button name="decision" value="approve" type="submit">Autorizar acesso</button> <button name="decision" value="deny" type="submit" formnovalidate>Cancelar</button></form></body></html>`);
    },
    async challengeForAuthorizationCode(client, code) {
      return validCode(client, code).codeChallenge;
    },
    async exchangeAuthorizationCode(client, code, _verifier, redirectUri, resource) {
      const entry = validCode(client, code);
      if (redirectUri !== entry.redirectUri) throw new InvalidGrantError('Endereço de retorno diferente do autorizado.');
      checkResource(resource, InvalidGrantError);
      const result = issueTokens(entry);
      codes.delete(code);
      return result;
    },
    async exchangeRefreshToken(client, refresh, requestedScopes, resource) {
      prune();
      const entry = tokens.get(refresh);
      if (!entry || entry.kind !== 'refresh' || entry.clientId !== client.client_id) throw new InvalidGrantError('Refresh token inválido ou expirado.');
      checkResource(resource, InvalidGrantError);
      const scopes = requestedScopes === undefined ? entry.scopes : scopesFor(requestedScopes);
      if (scopes.some(scope => !entry.scopes.includes(scope))) throw new InvalidScopeError('O token não pode ampliar as permissões autorizadas.');
      const result = issueTokens({...entry, scopes});
      tokens.delete(refresh);
      return result;
    },
    async verifyAccessToken(token) {
      prune();
      const entry = tokens.get(token);
      if (!entry || entry.kind !== 'access') throw new InvalidTokenError('Invalid or expired access token.');
      return {token, clientId:entry.clientId, scopes:[...entry.scopes], expiresAt:Math.floor(entry.expiresAt / 1000), resource:new URL(resourceUrl)};
    },
    async revokeToken(client, request) {
      prune();
      const entry = tokens.get(request.token);
      if (entry?.clientId === client.client_id) revokeGrant(entry.grantId);
    },
  };

  function approveHandler(request, response) {
    securePage(response);
    const timestamp = now();
    if (timestamp - loginWindowStart >= 60000) {loginWindowStart = timestamp; loginAttempts = 0;}
    if (++loginAttempts > 10) {
      response.setHeader('Retry-After', '60');
      return response.status(429).type('text').send('Muitas tentativas. Aguarde um minuto.');
    }
    prune();
    const {ticket, password:submitted, decision} = request.body || {};
    const entry = typeof ticket === 'string' ? pending.get(ticket) : undefined;
    if (!entry) return response.status(400).type('text').send('Pedido inválido ou expirado. Inicie a conexão novamente.');
    if (decision === 'deny') {
      pending.delete(ticket);
      return redirectWith(response, entry.redirectUri, {error:'access_denied', state:entry.state});
    }
    if (decision !== 'approve') return response.status(400).type('text').send('Decisão inválida.');
    if (typeof submitted !== 'string' || submitted.length > 1024 || !timingSafeEqual(digest(submitted), passwordHash)) {
      return response.status(401).type('text').send('Senha incorreta. Volte e tente novamente.');
    }
    try {
      bounded(codes, 256);
      const code = randomToken();
      codes.set(code, {...entry, expiresAt:now() + 120000});
      pending.delete(ticket);
      return redirectWith(response, entry.redirectUri, {code, state:entry.state});
    } catch {
      return response.status(503).type('text').send('Limite temporário atingido. Tente novamente mais tarde.');
    }
  }
  return {provider, approveHandler};
}
