import {realpath,lstat,readFile,writeFile,readdir,mkdir,rename,rm} from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash,randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';

const TEXT_EXTENSIONS=new Set(['.gd','.tscn','.tres','.godot','.cfg','.gdshader','.gdshaderinc','.json','.txt','.md','.svg']);
const OMIT=new Set(['.godot','.git','node_modules']);
const MAX_TEXT_BYTES=1024*1024;
const MAX_OUTPUT_CHARS=65536;
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');

/** One explicitly configured Godot project, no shell commands or arbitrary CLI flags. */
export class GodotBridge {
  #process=null;
  #closed=false;
  #writeTail=Promise.resolve();
  static async create({projectPath,godotBin='godot',env=process.env}={}){
    if(!projectPath)throw Error('Defina GODOT_PROJECT_PATH com a pasta que contém project.godot.');
    const root=await realpath(path.resolve(projectPath));
    const bridge=new GodotBridge(root,godotBin,env);
    await bridge.resolve('project.godot');
    await readFile(path.join(root,'project.godot'),'utf8');
    return bridge;
  }
  constructor(root,godotBin,env){this.root=root;this.godotBin=godotBin;this.env=env;}
  async resolve(input,{write=false,text=false}={}){
    if(typeof input!=='string'||!input||input.includes('\0'))throw Error('Caminho inválido.');
    const relative=input.replace(/^res:\/\//,'').replaceAll('\\','/');
    if(path.posix.isAbsolute(relative)||path.win32.isAbsolute(relative)||relative.split('/').some(x=>x==='..')||relative.startsWith('-'))throw Error('Caminho deve permanecer dentro do projeto.');
    const parts=relative.split('/').filter(x=>x&&x!=='.');
    if(!parts.length||parts.some(x=>OMIT.has(x)))throw Error('Caminho interno não permitido.');
    if(text&&!TEXT_EXTENSIONS.has(path.extname(relative).toLowerCase()))throw Error('Extensão não permitida para leitura/edição de texto.');
    let current=this.root;
    for(let index=0;index<parts.length;index++){
      current=path.join(current,parts[index]);
      try{
        const stat=await lstat(current);
        if(stat.isSymbolicLink())throw Error('Link simbólico não permitido no caminho do projeto.');
        if(index<parts.length-1&&!stat.isDirectory())throw Error('Caminho intermediário não é pasta.');
      }catch(error){if(error.code==='ENOENT'&&write)break;throw error;}
    }
    const target=path.join(this.root,...parts);
    if(!target.startsWith(this.root+path.sep))throw Error('Caminho fora do projeto.');
    return target;
  }
  async info(){
    const config=await readFile(await this.resolve('project.godot'),'utf8');
    const match=config.match(/^config\/name\s*=\s*("(?:[^"\\]|\\.)*")/m);
    let projectName='Godot';try{if(match)projectName=JSON.parse(match[1]);}catch{}
    return {projectName,projectPath:this.root,godotExecutable:this.godotBin,scope:'Only this configured project',transport:'MCP'};
  }
  async listFiles(){
    const files=[];let truncated=false;
    const walk=async(dir,prefix='')=>{
      for(const item of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
        if(OMIT.has(item.name)||item.isSymbolicLink())continue;
        if(files.length>=500){truncated=true;return;}
        const relative=prefix+item.name;
        if(item.isDirectory())await walk(path.join(dir,item.name),relative+'/');
        else if(item.isFile())files.push(relative);
      }
    };
    await walk(this.root);return {files,truncated};
  }
  async readFile(input){
    const target=await this.resolve(input,{text:true});
    const stat=await lstat(target);if(!stat.isFile()||stat.size>MAX_TEXT_BYTES)throw Error('Arquivo precisa ser texto e ter até 1 MiB.');
    const bytes=await readFile(target);if(bytes.includes(0))throw Error('Arquivo binário não permitido.');
    return {path:path.relative(this.root,target).replaceAll(path.sep,'/'),content:bytes.toString('utf8'),sha256:hash(bytes)};
  }
  writeFile(input,content,expectedSha256){
    const operation=this.#writeTail.then(()=>this.#writeFile(input,content,expectedSha256));
    this.#writeTail=operation.catch(()=>{});
    return operation;
  }
  async #writeFile(input,content,expectedSha256){
    if(typeof content!=='string'||Buffer.byteLength(content)>MAX_TEXT_BYTES||content.includes('\0'))throw Error('Texto precisa ter até 1 MiB e não pode conter bytes nulos.');
    const target=await this.resolve(input,{write:true,text:true});
    let exists=false;
    try{const original=await readFile(target);exists=true;if(!expectedSha256||hash(original)!==expectedSha256)throw Error('Hash sha256 ausente ou arquivo modificado. Leia o arquivo antes de sobrescrever.');}
    catch(error){if(error.code!=='ENOENT')throw error;if(expectedSha256)throw Error('Arquivo não existe; hash esperado não corresponde.');}
    await mkdir(path.dirname(target),{recursive:true});
    // Atomic replacement does not follow a destination symlink appearing between checks.
    await this.resolve(input,{write:true,text:true});
    const temporary=target+'.mcp-'+randomUUID();
    try{await writeFile(temporary,content,{flag:'wx',mode:0o600});await rename(temporary,target);}finally{await rm(temporary,{force:true});}
    return {path:path.relative(this.root,target).replaceAll(path.sep,'/'),sha256:hash(Buffer.from(content)),created:!exists};
  }
  #reserve(kind){
    if(this.#closed)throw Error('A ponte foi encerrada.');
    if(this.#process?.busy)throw Error('Godot já está em execução ou iniciando. Pare-o antes de outra operação.');
    const state={child:null,busy:true,starting:true,running:false,kind,output:'',exitCode:null,signal:null,stopRequested:false,timedOut:false,completed:null};
    this.#process=state;return state;
  }
  #snapshot(state=this.#process){
    return {running:state?.running??false,starting:state?.starting??false,kind:state?.kind??null,pid:state?.running?state.child.pid:null,exitCode:state?.exitCode??null,output:state?.output??''};
  }
  #cancelUnspawned(state){state.busy=false;state.starting=false;state.running=false;}
  async checkProject(script){
    const state=this.#reserve('check');
    try{
      let args=['--headless','--editor','--path',this.root,'--import','--quit'];
      if(script){
        const target=await this.resolve(script,{text:true});if(path.extname(target)!=='.gd')throw Error('A verificação de script aceita somente .gd.');
        args=['--headless','--path',this.root,'--check-only','--script','res://'+path.relative(this.root,target).replaceAll(path.sep,'/')];
      }
      if(state.stopRequested)return {ok:false,cancelled:true,...this.#snapshot(state)};
      await this.#start(args,state);
      const timer=setTimeout(()=>{state.timedOut=true;state.child.kill('SIGKILL');},30000);
      try{await state.completed;}finally{clearTimeout(timer);}
      return {ok:!state.timedOut&&!state.stopRequested&&state.exitCode===0&&!/SCRIPT ERROR:|Parse Error:|ERROR:/i.test(state.output),exitCode:state.exitCode,signal:state.signal,timedOut:state.timedOut,output:state.output};
    }catch(error){if(!state.child)this.#cancelUnspawned(state);throw error;}
  }
  async runProject(scene){
    const state=this.#reserve('headless');
    try{
      const args=['--headless','--path',this.root];
      if(scene){const target=await this.resolve(scene);if(path.extname(target)!=='.tscn')throw Error('Cena precisa usar extensão .tscn.');args.push('res://'+path.relative(this.root,target).replaceAll(path.sep,'/'));}
      if(state.stopRequested)return this.#snapshot(state);
      return await this.#start(args,state);
    }catch(error){if(!state.child)this.#cancelUnspawned(state);throw error;}
  }
  async launchEditor(){
    const state=this.#reserve('editor');
    return this.#start(['--editor','--path',this.root],state);
  }
  async #start(args,state){
    if(state.stopRequested){this.#cancelUnspawned(state);return this.#snapshot(state);}
    const child=spawn(this.godotBin,args,{cwd:this.root,env:this.env,shell:false,windowsHide:true});state.child=child;
    const append=data=>{state.output=(state.output+data.toString()).slice(-MAX_OUTPUT_CHARS);};
    child.stdout.on('data',append);child.stderr.on('data',append);
    state.completed=new Promise(resolve=>{
      child.once('close',(code,signal)=>{state.running=false;state.starting=false;state.busy=false;state.exitCode=code;state.signal=signal;resolve();});
      child.once('error',()=>{state.running=false;state.starting=false;state.busy=false;resolve();});
    });
    await new Promise((resolve,reject)=>{
      child.once('spawn',()=>{state.starting=false;state.running=true;if(state.stopRequested)child.kill('SIGTERM');resolve();});
      child.once('error',error=>{reject(Error('Não foi possível executar Godot: '+error.message));});
    });
    return this.#snapshot(state);
  }
  output(){return this.#snapshot();}
  async stopProject(){
    const state=this.#process;
    if(state?.busy){
      state.stopRequested=true;
      if(!state.child){this.#cancelUnspawned(state);return this.#snapshot(state);}
      state.child.kill('SIGTERM');
      await Promise.race([state.completed,delay(2000)]);
      if(state.busy){state.child.kill('SIGKILL');await Promise.race([state.completed,delay(2000)]);}
      if(state.busy)throw Error('Godot ainda está encerrando. Consulte a saída novamente.');
    }
    return this.#snapshot(state);
  }
  async close(){this.#closed=true;await this.stopProject();await this.#writeTail;}
}
