import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,rm} from 'node:fs/promises';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import {createHttpServer} from '../src/server.mjs';
import {GodotBridge} from '../src/bridge.mjs';
const here=fileURLToPath(new URL('../',import.meta.url));
const password='only-for-test-owner-password-12345';
async function fixture(t){const dir=await mkdtemp(path.join(tmpdir(),'godot-mcp-protocol-'));await cp(new URL('../example-project/',import.meta.url),path.join(dir,'project'),{recursive:true});t.after(()=>rm(dir,{recursive:true,force:true}));return path.join(dir,'project');}
test('SDK client initializes over real stdio, discovers tools and edits the configured project',async t=>{
 const project=await fixture(t);
 const transport=new StdioClientTransport({command:process.execPath,args:[path.join(here,'src/server.mjs'),'--stdio'],env:{...process.env,GODOT_PROJECT_PATH:project},stderr:'pipe'});
 const client=new Client({name:'godot-mcp-test',version:'1.0.0'});t.after(()=>client.close());await client.connect(transport);
 const tools=await client.listTools();assert.ok(tools.tools.some(x=>x.name==='run_project'));assert.ok(tools.tools.some(x=>x.name==='write_project_file'));
 const info=await client.callTool({name:'get_project_info',arguments:{}});assert.equal(info.isError,undefined);assert.equal(info.structuredContent.projectName,'Godot MCP - Exemplo');
 const read=await client.callTool({name:'read_project_file',arguments:{path:'main.gd'}});assert.match(read.structuredContent.content,/GODOT_MCP_READY/);
 const written=await client.callTool({name:'write_project_file',arguments:{path:'main.gd',content:read.structuredContent.content+'\n# via MCP\n',expectedSha256:read.structuredContent.sha256}});assert.equal(written.structuredContent.created,false);
 const rejected=await client.callTool({name:'read_project_file',arguments:{path:'../secret.gd'}});assert.equal(rejected.isError,true);
});
test('HTTP MCP advertises OAuth discovery and denies unauthenticated writes',async t=>{
 const project=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 const {listener,close}=await createHttpServer({bridge,publicUrl:'http://127.0.0.1:3978',password,port:0});t.after(close);
 const base='http://127.0.0.1:'+listener.address().port;
 const metadata=await fetch(base+'/.well-known/oauth-protected-resource/mcp');assert.equal(metadata.status,200);assert.equal((await metadata.json()).resource,'http://127.0.0.1:3978/mcp');
 const response=await fetch(base+'/mcp',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'write_project_file',arguments:{path:'main.gd',content:'bad'}}})});
 assert.equal(response.status,401);assert.match(response.headers.get('www-authenticate'),/oauth-protected-resource/);
 assert.match((await bridge.readFile('main.gd')).content,/GODOT_MCP_READY/);
 const health=await fetch(base+'/health');assert.equal(health.status,200);assert.equal((await health.json()).ok,true);
});
test('rejects an insecure public HTTP origin and weak owner password',async t=>{
 const project=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 await assert.rejects(createHttpServer({bridge,publicUrl:'http://public.example.com',password,port:0}),/HTTPS|https/);
 await assert.rejects(createHttpServer({bridge,publicUrl:'http://127.0.0.1:3978',password:'short',port:0}),/16|senha|password/i);
});

test('HTTP SDK client uses a real owner-approved OAuth token and enforced scopes',async t=>{
 const {createHash}=await import('node:crypto');
 const project=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 const resource='http://127.0.0.1:3978/mcp';
 const {listener,close}=await createHttpServer({bridge,publicUrl:'http://127.0.0.1:3978',password,port:0});t.after(close);
 const base='http://127.0.0.1:'+listener.address().port;
 async function ownerToken(scope){
  const metadataResponse=await fetch(base+'/.well-known/oauth-authorization-server');assert.equal(metadataResponse.status,200);const metadata=await metadataResponse.json();assert.equal(metadata.issuer,'http://127.0.0.1:3978/');
  const registered=await fetch(base+'/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({client_name:'Test browser MCP client',redirect_uris:['http://localhost/callback'],token_endpoint_auth_method:'none',grant_types:['authorization_code','refresh_token'],response_types:['code']})});assert.equal(registered.status,201);const client=await registered.json();
  const verifier='q'.repeat(64),challenge=createHash('sha256').update(verifier).digest('base64url');
  const params=new URLSearchParams({response_type:'code',client_id:client.client_id,redirect_uri:'http://localhost/callback',code_challenge:challenge,code_challenge_method:'S256',state:'user-started',resource,scope});
  const authorize=await fetch(base+'/authorize?'+params,{redirect:'manual'});assert.equal(authorize.status,200);const html=await authorize.text();const ticket=html.match(/name="ticket"\s+value="([^"]+)"/)[1];
  const grant=await fetch(base+'/approve',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({ticket,password,decision:'approve'}),redirect:'manual'});assert.equal(grant.status,302);
  const code=new URL(grant.headers.get('location')).searchParams.get('code');
  const tokenResponse=await fetch(base+'/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'authorization_code',client_id:client.client_id,code,redirect_uri:'http://localhost/callback',code_verifier:verifier,resource})});assert.equal(tokenResponse.status,200);return (await tokenResponse.json()).access_token;
 }
 const token=await ownerToken('godot:read godot:write godot:run');
 const client=new Client({name:'browser-test',version:'1.0.0'});t.after(()=>client.close());
 const transport=new StreamableHTTPClientTransport(new URL(base+'/mcp'),{requestInit:{headers:{Authorization:'Bearer '+token}}});await client.connect(transport);
 const info=await client.callTool({name:'get_project_info',arguments:{}});assert.equal(info.structuredContent.projectName,'Godot MCP - Exemplo');
 const created=await client.callTool({name:'write_project_file',arguments:{path:'via-http.gd',content:'extends Node\n'}});assert.equal(created.structuredContent.created,true);
 const limitedToken=await ownerToken('godot:read');
 const readonly=new Client({name:'readonly-test',version:'1.0.0'});t.after(()=>readonly.close());
 await readonly.connect(new StreamableHTTPClientTransport(new URL(base+'/mcp'),{requestInit:{headers:{Authorization:'Bearer '+limitedToken}}}));
 const denied=await readonly.callTool({name:'write_project_file',arguments:{path:'denied.gd',content:'bad'}});assert.equal(denied.isError,true);assert.match(denied.content[0].text,/godot:write/);
 assert.ok(!(await bridge.listFiles()).files.includes('denied.gd'));
});
