import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,rm,readFile,writeFile,symlink,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {GodotBridge} from '../src/bridge.mjs';
const example=new URL('../example-project/',import.meta.url);
async function fixture(t){
 const temporary=await mkdtemp(path.join(tmpdir(),'godot-mcp-test-'));const project=path.join(temporary,'project');await cp(example,project,{recursive:true});
 t.after(()=>rm(temporary,{recursive:true,force:true}));
 return {temporary,project};
}
test('reads and updates a real project with hashes, without stale overwrites',async t=>{
 const {project}=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 assert.equal((await bridge.info()).projectName,'Godot MCP - Exemplo');
 assert.ok((await bridge.listFiles()).files.includes('main.tscn'));
 const original=await bridge.readFile('res://main.gd');assert.match(original.content,/GODOT_MCP_READY/);
 await assert.rejects(bridge.writeFile('main.gd','new'),/sha256|hash/i);
 await bridge.writeFile('main.gd',original.content+'\n# test\n',original.sha256);
 await assert.rejects(bridge.writeFile('main.gd','stale',original.sha256),/modificado|hash|changed/i);
 await bridge.writeFile('scripts/new.gd','extends Node\n');assert.equal((await bridge.readFile('scripts/new.gd')).content,'extends Node\n');
 assert.ok((await bridge.listFiles()).files.includes('scripts/new.gd'));
});
test('rejects traversal, absolute paths, unsupported files and escaping symlinks',async t=>{
 const {project,temporary}=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 await writeFile(path.join(temporary,'outside.gd'),'secret');
 await symlink(path.join(temporary,'outside.gd'),path.join(project,'linked.gd'));
 await mkdir(path.join(temporary,'external'));await symlink(path.join(temporary,'external'),path.join(project,'linked-dir'));
 for(const p of ['../outside.gd','/etc/passwd','C:\\Windows\\secret.gd','linked.gd','linked-dir/new.gd','main.png']){
  await assert.rejects(bridge.readFile(p),/caminho|path|simbólico|symbolic|permitid|extensão|extension/i,p);
  await assert.rejects(bridge.writeFile(p,'bad'),/caminho|path|simbólico|symbolic|permitid|extensão|extension/i,p);
 }
 assert.equal(await readFile(path.join(temporary,'outside.gd'),'utf8'),'secret');
});
const godot=process.env.GODOT_BIN||'godot';
const available=spawnSync(godot,['--version'],{encoding:'utf8'}).status===0;
test('runs an actual Godot 4 project, captures output, and stops the managed process',{skip:!available,timeout:40000},async t=>{
 const {project,temporary}=await fixture(t);
 const env={...process.env,XDG_CACHE_HOME:path.join(temporary,'cache'),XDG_DATA_HOME:path.join(temporary,'data'),XDG_CONFIG_HOME:path.join(temporary,'config')};
 for(const name of ['cache','data','config'])await mkdir(path.join(temporary,name));
 const bridge=await GodotBridge.create({projectPath:project,godotBin:godot,env});t.after(()=>bridge.close());
 const check=await bridge.checkProject();assert.equal(check.ok,true,check.output);
 const started=await bridge.runProject();assert.equal(started.running,true);
 await assert.rejects(bridge.runProject(),/execução|running/i);
 let output;for(let n=0;n<80;n++){output=bridge.output();if(output.output.includes('GODOT_MCP_READY'))break;await delay(100);}
 assert.match(output.output,/GODOT_MCP_READY/);assert.equal(output.running,true);
 const stopped=await bridge.stopProject();assert.equal(stopped.running,false);
 assert.equal(bridge.output().running,false);
 // Parse errors must be detected even if an engine/editor invocation returns exit code zero.
 const original=await bridge.readFile('main.gd');await bridge.writeFile('main.gd','extends Node2D\nfunc broken(\n',original.sha256);
 const bad=await bridge.checkProject('main.gd');assert.equal(bad.ok,false);assert.match(bad.output,/Parse Error|ERROR|Expected/i);
});
test('reports an unavailable executable without hanging or leaving a running process',async t=>{
 const {project}=await fixture(t);const bridge=await GodotBridge.create({projectPath:project,godotBin:path.join(project,'missing-binary')});t.after(()=>bridge.close());
 await assert.rejects(bridge.runProject(),/Godot|executável|ENOENT/i);assert.equal(bridge.output().running,false);
});

test('reserves the engine slot before async scene resolution and cancels pending starts',{skip:!available,timeout:15000},async t=>{
 const {project,temporary}=await fixture(t);const env={...process.env,XDG_CACHE_HOME:path.join(temporary,'cache'),XDG_DATA_HOME:path.join(temporary,'data'),XDG_CONFIG_HOME:path.join(temporary,'config')};
 for(const name of ['cache','data','config'])await mkdir(path.join(temporary,name));
 const bridge=await GodotBridge.create({projectPath:project,godotBin:godot,env});t.after(()=>bridge.close());
 const starts=await Promise.allSettled([bridge.runProject('main.tscn'),bridge.runProject('main.tscn')]);
 assert.equal(starts.filter(x=>x.status==='fulfilled').length,1,'Exactly one concurrent start may spawn');
 assert.equal(starts.filter(x=>x.status==='rejected').length,1);
 const pid=bridge.output().pid;assert.ok(pid);await assert.rejects(bridge.checkProject(),/execução|running|inici/i);await bridge.stopProject();
 assert.throws(()=>process.kill(pid,0),/ESRCH|not found|no such process/i,'The only spawned child must be reaped');
 const pending=bridge.runProject('main.tscn');await bridge.stopProject();await pending;assert.equal(bridge.output().running,false);
 const checking=bridge.checkProject();await assert.rejects(bridge.runProject(),/execução|running|inici/i);await checking;
 await bridge.close();await assert.rejects(bridge.runProject(),/encerrad|closed/i);
});

test('serializes same-file writes so stale concurrent edits or creates cannot both succeed',async t=>{
 const {project}=await fixture(t);const bridge=await GodotBridge.create({projectPath:project});t.after(()=>bridge.close());
 const original=await bridge.readFile('main.gd');
 const edits=await Promise.allSettled([bridge.writeFile('main.gd','edit A',original.sha256),bridge.writeFile('main.gd','edit B',original.sha256)]);
 assert.equal(edits.filter(x=>x.status==='fulfilled').length,1);assert.equal(edits.filter(x=>x.status==='rejected').length,1);
 const creates=await Promise.allSettled([bridge.writeFile('new.gd','create A'),bridge.writeFile('new.gd','create B')]);
 assert.equal(creates.filter(x=>x.status==='fulfilled').length,1);assert.equal(creates.filter(x=>x.status==='rejected').length,1);
});
