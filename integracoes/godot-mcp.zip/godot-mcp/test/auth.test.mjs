import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import express from 'express';
import {mcpAuthRouter} from '@modelcontextprotocol/sdk/server/auth/router.js';
import {createOwnerAuth} from '../src/auth.mjs';

const password='test-owner-passphrase-32-characters';
const publicUrl=new URL('https://godot.example/');
const resource=new URL('/mcp',publicUrl).href;
const verifier='x'.repeat(64);
const challenge=createHash('sha256').update(verifier).digest('base64url');
async function fixture(t){
 let time=Date.now();
 const auth=createOwnerAuth({publicUrl,password,now:()=>time});
 const app=express();
 app.post('/approve',express.urlencoded({extended:false,limit:'8kb'}),auth.approveHandler);
 app.use(mcpAuthRouter({provider:auth.provider,issuerUrl:publicUrl,resourceServerUrl:new URL(resource),scopesSupported:['godot:read','godot:write','godot:run'],authorizationOptions:{rateLimit:false},clientRegistrationOptions:{rateLimit:false},tokenOptions:{rateLimit:false},revocationOptions:{rateLimit:false}}));
 const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
 t.after(()=>new Promise(resolve=>server.close(resolve)));
 const base=`http://127.0.0.1:${server.address().port}`;
 const post=(path,data)=>fetch(base+path,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data),redirect:'manual'});
 const register=async(name='client')=>{const r=await fetch(base+'/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({redirect_uris:['https://client.example/callback?keep=1'],client_name:name,token_endpoint_auth_method:'none',grant_types:['authorization_code','refresh_token'],response_types:['code']})});assert.equal(r.status,201);return r.json();};
 const authorize=async(client,overrides={})=>{
  const p=new URLSearchParams({response_type:'code',client_id:client.client_id,redirect_uri:client.redirect_uris[0],code_challenge:challenge,code_challenge_method:'S256',resource,state:'original-state',scope:'godot:read godot:write godot:run',...overrides});
  const r=await fetch(base+'/authorize?'+p,{redirect:'manual'});const html=await r.text();
  return {response:r,html,ticket:html.match(/name="ticket"\s+value="([^"]+)"/)?.[1]};
 };
 const approve=async(ticket,extra={})=>post('/approve',{ticket,password,decision:'approve',...extra});
 const codeFor=async(client,overrides={})=>{const pending=await authorize(client,overrides);assert.equal(pending.response.status,200,pending.html);assert.ok(pending.ticket);const approved=await approve(pending.ticket);assert.equal(approved.status,302,await approved.text());return new URL(approved.headers.get('location')).searchParams.get('code');};
 const exchange=(client,code,overrides={})=>post('/token',{client_id:client.client_id,grant_type:'authorization_code',code,code_verifier:verifier,redirect_uri:client.redirect_uris[0],resource,...overrides});
 return {...auth,base,post,register,authorize,approve,codeFor,exchange,advance:ms=>{time+=ms;}};
}

test('OAuth requires owner consent and SDK PKCE before issuing a bound single-use token',async t=>{
 const f=await fixture(t);const client=await f.register('<script>bad()</script>');
 const p=await f.authorize(client);assert.equal(p.response.status,200);assert.ok(p.ticket);assert.ok(p.html.includes('&lt;script&gt;'));assert.ok(!p.html.includes('<script>bad()'));
 assert.equal(p.response.headers.get('cache-control'),'no-store');assert.match(p.response.headers.get('content-security-policy'),/frame-ancestors 'none'/);
 assert.equal((await f.approve(p.ticket,{password:'wrong-password'})).status,401);
 const granted=await f.approve(p.ticket);assert.equal(granted.status,302);const location=new URL(granted.headers.get('location'));
 assert.equal(location.searchParams.get('state'),'original-state');assert.equal(location.searchParams.get('keep'),'1');
 assert.equal((await f.approve(p.ticket)).status,400);
 const code=location.searchParams.get('code');
 let response=await f.exchange(client,code,{code_verifier:'y'.repeat(64)});assert.equal(response.status,400);assert.equal((await response.json()).error,'invalid_grant');
 response=await f.exchange(client,code);assert.equal(response.status,200);const tokens=await response.json();
 const info=await f.provider.verifyAccessToken(tokens.access_token);assert.equal(info.clientId,client.client_id);assert.equal(info.resource.href,resource);assert.deepEqual(info.scopes,['godot:read','godot:write','godot:run']);
 assert.equal((await f.exchange(client,code)).status,400);
});

test('authorization code cannot be exchanged by another client, redirect, or resource',async t=>{
 const f=await fixture(t),client=await f.register(),other=await f.register('other');
 const code=await f.codeFor(client);
 for(const [c,patch] of [[other,{}],[client,{redirect_uri:'https://attacker.example/callback'}],[client,{resource:'https://attacker.example/mcp'}]]){
  const r=await f.exchange(c,code,patch);assert.equal(r.status,400);assert.equal((await r.json()).error,'invalid_grant');
 }
 assert.equal((await f.exchange(client,code)).status,200);
});

test('authorization rejects foreign resources and unknown scopes without granting a code',async t=>{
 const f=await fixture(t),client=await f.register();
 assert.equal((await f.authorize(client,{resource:'https://attacker.example/mcp'})).response.status,302);
 const unknown=await f.authorize(client,{scope:'godot:admin'});assert.equal(unknown.response.status,302);assert.match(unknown.response.headers.get('location'),/error=invalid_scope/);
});

test('pending requests, codes, and access tokens expire',async t=>{
 const f=await fixture(t),client=await f.register();
 const pending=await f.authorize(client);f.advance(600001);assert.equal((await f.approve(pending.ticket)).status,400);
 let code=await f.codeFor(client);f.advance(120001);assert.equal((await f.exchange(client,code)).status,400);
 code=await f.codeFor(client);const tokens=await (await f.exchange(client,code)).json();f.advance(3600001);
 await assert.rejects(()=>f.provider.verifyAccessToken(tokens.access_token),/expired|Invalid/i);
});

test('refresh rotates and cannot expand scopes; revocation invalidates the grant',async t=>{
 const f=await fixture(t),client=await f.register();const code=await f.codeFor(client,{scope:'godot:read'});
 const first=await (await f.exchange(client,code)).json();
 let r=await f.post('/token',{client_id:client.client_id,grant_type:'refresh_token',refresh_token:first.refresh_token,resource,scope:'godot:write'});assert.equal(r.status,400);
 r=await f.post('/token',{client_id:client.client_id,grant_type:'refresh_token',refresh_token:first.refresh_token,resource,scope:'godot:read'});assert.equal(r.status,200);const second=await r.json();assert.notEqual(second.refresh_token,first.refresh_token);
 assert.equal((await f.post('/token',{client_id:client.client_id,grant_type:'refresh_token',refresh_token:first.refresh_token,resource})).status,400);
 assert.equal((await f.post('/revoke',{client_id:client.client_id,token:second.refresh_token})).status,200);
 await assert.rejects(()=>f.provider.verifyAccessToken(second.access_token));await assert.rejects(()=>f.provider.verifyAccessToken(first.access_token));
});

test('deny never grants a code and owner login attempts are rate limited',async t=>{
 const f=await fixture(t),client=await f.register();let p=await f.authorize(client);
 const deny=await f.approve(p.ticket,{decision:'deny'});assert.equal(deny.status,302);assert.match(deny.headers.get('location'),/error=access_denied/);assert.ok(!deny.headers.get('location').includes('code='));
 p=await f.authorize(client);
 for(let i=0;i<9;i++)await f.approve(p.ticket,{password:'wrong'});
 const limited=await f.approve(p.ticket,{password:'wrong'});assert.equal(limited.status,429);
});

test('owner passphrase must be strong enough for remote authorization',()=>{
 assert.throws(()=>createOwnerAuth({publicUrl,password:'short'}),/16/);
});

test('remote origin must be HTTPS without a path or URL credentials',()=>{
 for(const value of ['http://godot.example/','https://godot.example/nested/','https://owner:secret@godot.example/','https://godot.example/?secret=yes']){
  assert.throws(()=>createOwnerAuth({publicUrl:new URL(value),password}));
 }
 assert.doesNotThrow(()=>createOwnerAuth({publicUrl:new URL('http://127.0.0.1:3978/'),password}));
});

test('registered callbacks reject insecure remote URLs and fragments',async t=>{
 const f=await fixture(t);
 for(const callback of ['http://attacker.example/callback','https://client.example/callback#fragment','https://user:secret@client.example/callback']){
  const r=await fetch(f.base+'/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({redirect_uris:[callback],token_endpoint_auth_method:'none'})});
  assert.equal(r.status,400);assert.equal((await r.json()).error,'invalid_client_metadata');
 }
});

test('a different client cannot refresh or revoke the owner grant',async t=>{
 const f=await fixture(t),client=await f.register(),other=await f.register('other');
 const code=await f.codeFor(client);const tokens=await (await f.exchange(client,code)).json();
 const refresh=await f.post('/token',{client_id:other.client_id,grant_type:'refresh_token',refresh_token:tokens.refresh_token,resource});
 assert.equal(refresh.status,400);
 const revoked=await f.post('/revoke',{client_id:other.client_id,token:tokens.refresh_token});assert.equal(revoked.status,200);
 assert.equal((await f.provider.verifyAccessToken(tokens.access_token)).clientId,client.client_id);
 assert.equal((await f.post('/token',{client_id:client.client_id,grant_type:'refresh_token',refresh_token:tokens.refresh_token,resource})).status,200);
});
